package aplikazioa;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

import moduloak.OnlineLiburua;

public class Aplikazio {

	public static void main(String[] args) throws IOException {
		ArrayList<OnlineLiburua> onlineLiburuas = new ArrayList<OnlineLiburua>();
		File file = new File("./src/Liburuak.txt");
		Scanner scFile = new Scanner(file);
		Scanner scan = new Scanner(System.in);
		OnlineLiburua liburua = new OnlineLiburua();
		String [] data=null;
		String line = null;
		int k1=0,k2=0;
		Fitxategiaburutu(file, scFile, scan, data, line, k1, k2, onlineLiburuas, liburua);
		scFile.close();
		scan.close();
	}
	private static void Fitxategiaburutu(File file,Scanner scFile,Scanner scan,String [] data,String line,
			int k1,int k2,ArrayList<OnlineLiburua> onlineLiburuas, OnlineLiburua liburua) throws IOException {
		while (scFile.hasNext()) {
			scFile.nextLine();
			k1++;
		}
//		k1=k1-1;
		int[] id = new int[k1];
		String[] mota = new String[k1];
		String[] izenburua = new String[k1];
		String[] egilea = new String[k1];
		String[] isbn = new String[k1];
		double[] prezioa = new double[k1];
		double[] pesoGr = new double[k1];
		scFile = new Scanner(file);
//		scFile.nextLine();
		k1=0;
		while (scFile.hasNext()) {
			line=scFile.nextLine();
			data=line.split(":");
			id[k1]=Integer.parseInt(data[0]);
			mota[k1]=data[1];
			izenburua[k1]=data[2];
			egilea[k1]=data[3];
			isbn[k1]=data[4];
			prezioa[k1]=Double.parseDouble(data[5]);
			pesoGr[k1]=Double.parseDouble(data[6]);
//			System.out.println(line);
			k1++;
		}
		System.out.println("Online liburuak:");
		while (scFile.hasNext()) {
//		for (int i = 0; i < onlineLiburuas.size(); i++) {
				liburua = new OnlineLiburua();
				liburua.getId();
				liburua.getMota();
				liburua.getIzenburua(); 
				liburua.getEgilea();
				liburua.getIsbn();
				liburua.getPrezioa();
				liburua.getPesoGr();
				onlineLiburuas.add(liburua);
				System.out.println(liburua);
//				id, mota, izenburua, egilea, isbn, prezioa, pesoGr
		}
		for (int i = 0; i < onlineLiburuas.size(); i++) {
			System.out.println(liburua);
		}
	}
}