package moduloak;

public class OnlineLiburua extends Liburua {
	double pesoGr;

	public OnlineLiburua() {
		super();
	}

	public OnlineLiburua(double pesoGr, int id,String mota, String izenburua, String egilea, String isbn, double prezioa) {
		super(id, mota, izenburua, egilea, isbn, prezioa);
		this.pesoGr = pesoGr;
	}

	public double getPesoGr() {
		return pesoGr;
	}

	public void setPesoGr(double pesoGr) {
		this.pesoGr = pesoGr;
	}
	@Override
	public String toString() {
		return super.toString()+ "pesoGr=\" + pesoGr + \"";
	}
	private  double EskuratuPrezioa() {
		return super.getPrezioa() * 0.70;
	}

}
