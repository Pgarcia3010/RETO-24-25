-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 26-02-2025 a las 13:56:46
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `libros`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `libros`
--

CREATE TABLE `libros` (
  `id` int(11) NOT NULL,
  `tipo` varchar(1) NOT NULL,
  `nombre` varchar(80) NOT NULL,
  `autor` varchar(30) NOT NULL,
  `isbn` varchar(18) NOT NULL,
  `precio` double(3,2) NOT NULL,
  `pesoGr` double(3,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `libros`
--

INSERT INTO `libros` (`id`, `tipo`, `nombre`, `autor`, `isbn`, `precio`, `pesoGr`) VALUES
(1, 'F', 'Montaje y Mantenimiento de Sistemas y Componentes Informaticos Fpb', 'Cervantes Anton', '978-84-9171-382-1', 9.99, 9.99),
(2, 'F', 'Servicios en Red. Ciclos Formativos', 'Aa. Vv', '978-84-9732-765-7', 9.99, 9.99),
(3, 'F', 'Sistemas Operativos Monopuesto Cfgm', 'Ferrer Javier', '978-84-9171-377-7', 9.99, 9.99),
(4, 'F', 'Seguridad Informática (Edición 2020)', 'Postigo Palacios. Antonio', '978-84-283-4455-5', 9.99, 9.99),
(5, 'F', 'Aplicaciones Ofimaticas', 'Orrego Álvarez. José Manuel', '978-84-1357-178-2', 9.99, 9.99),
(6, 'D', 'DIGITALIZACIÓN APLICADA A LOS SECTORES PRODUCTIVOS GM (G. MEDIO)', 'Varios', 'AS 00552-2024', 9.99, 9.99),
(7, 'D', 'Inglés Formación Profesional Grado Medio', 'CHRYSTAL AGATHE TAO GREMY', '978- 84-128465-5-3', 9.99, 9.99),
(8, 'D', 'Digitalización aplicada al sistema productivo (Grado Superior) – Formato Digital', 'Guillermo García Sánchez', '978-84-127841-9-0', 9.99, 9.99),
(9, 'D', 'Moodle apunte digitalak', 'Irakasleak', '978-84-128731-9-5', 9.99, 9.99);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
