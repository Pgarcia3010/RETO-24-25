/**
 * 
 */
/**
 * 
 */
module azterketa2ebaluazioalehioak {
	requires java.desktop;
	requires java.sql;
}