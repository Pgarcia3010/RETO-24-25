package conecxioa;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import moduloak.OnlineLiburua;

public class librosc {
	private static Connection conexioa() throws SQLException {
		String url = "jdbc:mysql://localhost:3306/libros";
		String username = "root";
		String password = "";
		Connection conectar = null;
		try {
			conectar = DriverManager.getConnection(url, username, password);
			System.out.println("Connecting.");
				
		} catch (SQLException e) {
			System.err.println("Problem Connecting." + e.getMessage());
		}
		return conectar;
	}
	
	public static void lortuLiburua(OnlineLiburua onlineLiburua) throws SQLException {
		Connection conectar = conexioa();
		Statement st = conectar.createStatement();
		String consulta = "SELECT * FROM libros WHERE isbn = "+onlineLiburua+";";
		ResultSet resultSet = (ResultSet)st.executeQuery(consulta);
		try {
			while (resultSet.next()) {
				onlineLiburua.setId(resultSet.getInt("id"));
				onlineLiburua.setMota(resultSet.getString("tipo"));
				onlineLiburua.setIzenburua(resultSet.getString("nombre"));
				onlineLiburua.setEgilea(resultSet.getString("autor"));
				onlineLiburua.setIsbn(resultSet.getString("isbn"));
				onlineLiburua.setPrezioa(resultSet.getDouble("precio"));
				onlineLiburua.setPesoGr(resultSet.getDouble("pesoGr"));
				System.out.println(onlineLiburua);
			}
		} catch (Exception e) {
			System.err.println("Arazoa datu basearekin.");
		}
	}
	public void liburuakEzabatu(OnlineLiburua onlineLiburua)throws SQLException {
		Connection conectar = conexioa();
		Statement statement = conectar.createStatement();
//		String consulta2 = "SELECT * FROM libros WHERE isbn LIKE '"+onlineLiburua.getIsbn()+"';";
		String consulta = "DELETE FROM libros WHERE isbn LIKE '"+onlineLiburua.getIsbn()+"';";
		int resultado = statement.executeUpdate(consulta);
		if (resultado > 0) {
			System.out.println("Liburua ezabatuta.");
		} else {
			System.out.println("Liburua ezin izan da ezabatu.");
		}
		conectar.close();
	}
	public static OnlineLiburua getIsbn(OnlineLiburua onlineLiburua) throws SQLException {
		Connection con = conexioa();
		Statement st = con.createStatement();
		String consulta = "SELECT * FROM libros WHERE isbn LIKE '"+onlineLiburua.getIsbn()+"';";
		ResultSet resultSet = st.executeQuery(consulta);
		
		while(resultSet.next()) {
			onlineLiburua.setId(resultSet.getInt("id"));
			onlineLiburua.setMota(resultSet.getString("tipo"));
			onlineLiburua.setIzenburua(resultSet.getString("nombre"));
			onlineLiburua.setEgilea(resultSet.getString("autor"));
			onlineLiburua.setIsbn(resultSet.getString("isbn"));
			onlineLiburua.setPrezioa(resultSet.getDouble("precio"));
			onlineLiburua.setPesoGr(resultSet.getDouble("pesoGr"));
		}
		return onlineLiburua;
	}
	public void ErregistratuLiburua(OnlineLiburua lib)throws SQLException {
		Connection conectar = conexioa();
		Statement statement =conectar.createStatement();
		String consulta = "INSERT INTO `libros`(`id`, `tipo`, `nombre`, `autor`, `isbn`, `precio`, `pesoGr`) "
				+ "VALUES ('"+lib.getId()+"','"+lib.getMota()+"','"+lib.getIzenburua()+"','"+lib.getEgilea()+"','"+lib.getIsbn()+"','"+lib.getPrezioa()+"','"+lib.getPesoGr()+"');";
		int resultado = statement.executeUpdate(consulta);
		if (resultado > 0) {
			System.out.println("Liburua erregistratuta.");
		} else {
			System.out.println("Liburua txarto erregistratuta dago.");
		}
		conectar.close();
	}
	public void DatuakAldatu(OnlineLiburua lib)throws SQLException {
		Connection conectar = conexioa();
		Statement statement = conectar.createStatement();
		String consulta = "UPDATE `libros` SET `id`='["+lib.getId()+"]',`tipo`='["+lib.getMota()+"]',`nombre`='["+lib.getIzenburua()+"]',"
				+ "`autor`='["+lib.getEgilea()+"]', `isbn`='["+lib.getIsbn()+"]' ,`precio`='["+lib.getPrezioa()+"]',`pesoGr`='["+lib.getPesoGr()+"]'WHERE `isbn` = "+lib.getIsbn()+";";
		ResultSet resultSet = (ResultSet)statement.executeQuery(consulta);
	}
	public ArrayList<OnlineLiburua> getliburuak()throws SQLException {
		Connection conectar = conexioa();
		Statement st = conectar.createStatement();
		String consulta = "SELECT * FROM libros;";
		ResultSet resultSet = (ResultSet)st.executeQuery(consulta);
		ArrayList<OnlineLiburua> liburulist = new ArrayList<OnlineLiburua>();
		try {
			while (resultSet.next()) {
				OnlineLiburua onlineLiburua = new OnlineLiburua();
				onlineLiburua.setId(resultSet.getInt("id"));
				onlineLiburua.setMota(resultSet.getString("tipo"));
				onlineLiburua.setIzenburua(resultSet.getString("nombre"));
				onlineLiburua.setEgilea(resultSet.getString("autor"));
				onlineLiburua.setIsbn(resultSet.getString("isbn"));
				onlineLiburua.setPrezioa(resultSet.getDouble("precio"));
				onlineLiburua.setPesoGr(resultSet.getDouble("pesoGr"));
				liburulist.add(onlineLiburua);
			}
		} catch (Exception e) {
			System.err.println("Arazoa datu basearekin.");
		}
		return liburulist;
	}
}