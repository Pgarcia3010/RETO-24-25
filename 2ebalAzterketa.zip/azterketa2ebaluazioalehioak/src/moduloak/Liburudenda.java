package moduloak;

import java.util.ArrayList;

public class Liburudenda {
	String izena;
	ArrayList<OnlineLiburua> onlineliburua;
	public Liburudenda() {
		super();
	}
	public String getIzena() {
		return izena;
	}
	public void setIzena(String izena) {
		this.izena = izena;
	}
	public void anadirLiburua(OnlineLiburua Liburua) {
		onlineliburua.add(Liburua);
	}
	@Override
	public String toString() {
		String message = "Liburudenda: "+ izena+"]\n";
		message = message + "Liburuak:";
		for (OnlineLiburua liburuak: onlineliburua) {
			message += liburuak.toString()+ "\nn";
		}
		return message;
	}
}
