package moduloak;

public class Liburua {
	int id;
	String mota;
	String izenburua;
	String egilea;
	String isbn;
	double prezioa;
	public Liburua() {
		super();
	}
	public Liburua(int id, String mota, String izenburua, String egilea, String isbn, double prezioa) {
		super();
		this.id = id;
		this.mota = mota;
		this.izenburua = izenburua;
		this.egilea = egilea;
		this.isbn = isbn;
		this.prezioa = prezioa;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getMota() {
		return mota;
	}
	public void setMota(String mota) {
		this.mota = mota;
	}
	public String getIzenburua() {
		return izenburua;
	}
	public void setIzenburua(String izenburua) {
		this.izenburua = izenburua;
	}
	public String getEgilea() {
		return egilea;
	}
	public void setEgilea(String egilea) {
		this.egilea = egilea;
	}
	public String getIsbn() {
		return isbn;
	}
	public void setIsbn(String isbn) {
		this.isbn = isbn;
	}
	public double getPrezioa() {
		return prezioa;
	}
	public void setPrezioa(double prezioa) {
		this.prezioa = prezioa;
	}
	@Override
	public String toString() {
		return "Liburua [id=" + id + ", mota=" + mota + ", izenburua=" + izenburua + ", egilea=" + egilea + ", isbn="
				+ isbn + ", prezioa=" + prezioa + "]";
	}
	public double liburuprezioa() {
		return liburuprezioa();
	}
}
