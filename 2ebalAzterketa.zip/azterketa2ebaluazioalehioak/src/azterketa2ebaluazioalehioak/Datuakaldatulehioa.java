package azterketa2ebaluazioalehioak;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.security.PublicKey;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

import conecxioa.librosc;
import moduloak.OnlineLiburua;
import javax.swing.JTable; 

public class Datuakaldatulehioa {

	JFrame frame;
	private JTextField id;
	private JTextField tipo;
	private JTextField nombre;
	private JTextField autor;
	private JTextField precio;
	private JTextField pesogr;
	private JTextField isbn;
	private JTextField bilatzeko;
	private JTable table;
	JLabel lblNewLabel;
	JLabel lblNewLabel_1;
	JLabel lblNewLabel_1_1;
	JLabel lblNewLabel_1_2;
	JLabel lblNewLabel_1_3;
	JLabel lblNewLabel_1_4;
	JLabel lblNewLabel_2;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Datuakaldatulehioa window = new Datuakaldatulehioa();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Datuakaldatulehioa() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		/*
		 * Boton para volver al menu principal de la aplicacion.
		 */
		JButton Itzuli = new JButton("Itzuli.");
		Itzuli.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				Nagusia mainMenua = new Nagusia();
				mainMenua.frame.setVisible(true);
				frame.setVisible(false);
			}
		});
		Itzuli.setBounds(341, 232, 85, 21);
		frame.getContentPane().add(Itzuli);
		 /*
		  * Aqui se implementan las ventanas de texto, ventanas de escritura y botones dentro de la ventana.
		  */
		lblNewLabel = new JLabel("Id");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(10, 10, 45, 13);
		lblNewLabel.setVisible(false);
		
		lblNewLabel_1 = new JLabel("Tipo");
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setBounds(10, 33, 45, 13);
		lblNewLabel_1.setVisible(false);
		
		lblNewLabel_1_1 = new JLabel("Nombre");
		lblNewLabel_1_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_1.setBounds(10, 56, 45, 13);
		lblNewLabel_1_1.setVisible(false);
		
		lblNewLabel_1_2 = new JLabel("Autor");
		lblNewLabel_1_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_2.setBounds(10, 79, 45, 13);
		lblNewLabel_1_2.setVisible(false);
		
		lblNewLabel_1_3 = new JLabel("Precio");
		lblNewLabel_1_3.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_3.setBounds(10, 102, 45, 13);
		lblNewLabel_1_3.setVisible(false);
		
		lblNewLabel_1_4 = new JLabel("PesoGr");
		lblNewLabel_1_4.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_4.setBounds(10, 125, 45, 13);
		lblNewLabel_1_4.setVisible(false);
		
		lblNewLabel_2 = new JLabel("isbn");
		lblNewLabel_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_2.setBounds(10, 149, 46, 14);
		lblNewLabel_2.setVisible(false);
		
		isbn = new JTextField();
		isbn.setColumns(10);
		isbn.setBounds(65, 146, 96, 19);
		isbn.setVisible(false);
		
		id = new JTextField();
		id.setBounds(65, 7, 96, 19);
		id.setColumns(10);
		id.setVisible(false);
		
		tipo = new JTextField();
		tipo.setColumns(10);
		tipo.setBounds(65, 30, 96, 19);
		tipo.setVisible(false);
		
		nombre = new JTextField();
		nombre.setColumns(10);
		nombre.setBounds(65, 53, 96, 19);
		nombre.setVisible(false);
		
		autor = new JTextField();
		autor.setColumns(10);
		autor.setBounds(65, 76, 96, 19);
		autor.setVisible(false);
		
		precio = new JTextField();
		precio.setColumns(10);
		precio.setBounds(65, 99, 96, 19);
		precio.setVisible(false);
		
		pesogr = new JTextField();
		pesogr.setColumns(10);
		pesogr.setBounds(65, 122, 96, 19);
		pesogr.setVisible(false);
		
		JLabel erantzuna = new JLabel("");
		erantzuna.setBounds(107, 214, 220, 36);
		frame.getContentPane().add(erantzuna);
		
		JLabel Isbn = new JLabel("Bilatu Isbna.");
		Isbn.setHorizontalAlignment(SwingConstants.CENTER);
		Isbn.setBounds(10, 174, 85, 13);
		frame.getContentPane().add(Isbn);
		
		bilatzeko = new JTextField();
		bilatzeko.setBounds(10, 198, 96, 19);
		frame.getContentPane().add(bilatzeko);
		bilatzeko.setColumns(10);
		
		frame.getContentPane().add(lblNewLabel);
		frame.getContentPane().add(lblNewLabel_1);
		frame.getContentPane().add(lblNewLabel_1_1);
		frame.getContentPane().add(lblNewLabel_1_2);
		frame.getContentPane().add(lblNewLabel_1_3);
		frame.getContentPane().add(lblNewLabel_1_4);
		frame.getContentPane().add(lblNewLabel_2);
		frame.getContentPane().add(isbn);
		frame.getContentPane().add(id);
		frame.getContentPane().add(tipo);
		frame.getContentPane().add(nombre);
		frame.getContentPane().add(autor);
		frame.getContentPane().add(precio);
		frame.getContentPane().add(pesogr);
		
		/*
		 * Boton para buscar los datos.
		 */
		JButton bilatu = new JButton("Bilatu.");
		bilatu.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent e) {
				/*Aqui se crea un objeto,
				 * donde se le mete una variable de un cuadro de texto.
				 */
				OnlineLiburua onlineLiburua = new OnlineLiburua();
				onlineLiburua.setIsbn(bilatzeko.getText());
				/* Aqui se hace la llamada a la clase,
				 * que enviara el objeto a la base de datos.
				 * Si la operacion tiene exito los cuadros de texto apareceran.
				 */
					try {
						onlineLiburua = librosc.getIsbn(onlineLiburua);
						id.setText(String.valueOf(onlineLiburua.getId()));
						tipo.setText(onlineLiburua.getMota());
						nombre.setText(onlineLiburua.getIzenburua());
						autor.setText(onlineLiburua.getEgilea());
						isbn.setText(onlineLiburua.getIsbn());
						precio.setText(String.valueOf(onlineLiburua.getPrezioa()));
						pesogr.setText(String.valueOf(onlineLiburua.getPesoGr()));
						id.setVisible(true);
						tipo.setVisible(true);
						nombre.setVisible(true);
						autor.setVisible(true);
						isbn.setVisible(true);
						precio.setVisible(true);
						pesogr.setVisible(true);
						lblNewLabel.setVisible(true);
						lblNewLabel_1.setVisible(true);
						lblNewLabel_1_1.setVisible(true);
						lblNewLabel_1_2.setVisible(true);
						lblNewLabel_1_3.setVisible(true);
						lblNewLabel_1_4.setVisible(true);
						lblNewLabel_2.setVisible(true);
						System.out.println("Ondo doa.");
					} catch (SQLException e1) {
						System.err.println("Arazoa.");
						e1.printStackTrace();
					}
			}
		});
		bilatu.setBounds(116, 198, 85, 21);
		frame.getContentPane().add(bilatu);
		
		/*
		 * Boton para cambiar los datos.
		 * (No funciona)
		 */
		JButton Eguneraketa = new JButton("Eguneratu");
		Eguneraketa.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				librosc librosc = new librosc();
				int idString = Integer.parseInt(id.getText());
				String typeString = tipo.getText(), nameString = nombre.getText(), writerString = autor.getText(), isbnString = isbn.getText();
				double prizeString = Double.parseDouble(precio.getText()), weightString = Double.parseDouble(pesogr.getText());
				OnlineLiburua lib = new OnlineLiburua(idString, typeString, nameString, writerString, isbnString, prizeString, weightString);
				System.out.println(lib);
				try {
					librosc.DatuakAldatu(lib);
					erantzuna.setText("Aldaketa ondo burutu da.");
				}
				catch (Exception e2) {
					erantzuna.setText("Aldaketa ez da ondo burutu.");
					System.err.println("Errorea eguneratzerakoan.");
				}
			}
		});
		Eguneraketa.setBounds(10, 232, 85, 21);
		frame.getContentPane().add(Eguneraketa);
	}
	/*
	 * Metodo para recibir datos de la clase (BaloreaBidali).
	 */
	public void BaloreaJaso(OnlineLiburua onlineLiburua) {
		/*
		 * Una vez recibe los datos,
		 * los cuadros de texto apareceran con sus respectibos datos en su cuadro.
		 */
		id.setText(String.valueOf(onlineLiburua.getId()));
		tipo.setText(onlineLiburua.getMota());
		nombre.setText(onlineLiburua.getIzenburua());
		autor.setText(onlineLiburua.getEgilea());
		isbn.setText(onlineLiburua.getIsbn());
		precio.setText(String.valueOf(onlineLiburua.getPrezioa()));
		pesogr.setText(String.valueOf(onlineLiburua.getPesoGr()));
		id.setVisible(true);
		tipo.setVisible(true);
		nombre.setVisible(true);
		autor.setVisible(true);
		isbn.setVisible(true);
		precio.setVisible(true);
		pesogr.setVisible(true);
		lblNewLabel.setVisible(true);
		lblNewLabel_1.setVisible(true);
		lblNewLabel_1_1.setVisible(true);
		lblNewLabel_1_2.setVisible(true);
		lblNewLabel_1_3.setVisible(true);
		lblNewLabel_1_4.setVisible(true);
		lblNewLabel_2.setVisible(true);
	}
}
