package azterketa2ebaluazioalehioak;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.event.AncestorEvent;
import javax.swing.event.AncestorListener;

import conecxioa.librosc;
import moduloak.OnlineLiburua;

import javax.swing.JButton;
import javax.swing.SwingConstants;

public class Liburuakezabatzekolehioa {

	JFrame frame;
	private JTextField Isbn;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Liburuakezabatzekolehioa window = new Liburuakezabatzekolehioa();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Liburuakezabatzekolehioa() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel Emaitza = new JLabel("");
		Emaitza.setHorizontalAlignment(SwingConstants.CENTER);
		Emaitza.setBounds(10, 240, 191, 13);
		frame.getContentPane().add(Emaitza);
		
		Isbn = new JTextField();
		Isbn.setBounds(10, 10, 96, 19);
		frame.getContentPane().add(Isbn);
		Isbn.setColumns(10);
		
		JButton Bilatu = new JButton("Bilatu");
		Bilatu.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				librosc librosc = new librosc();
				String Tisbn = Isbn.getText();
				OnlineLiburua onlineLiburua = new OnlineLiburua();
				onlineLiburua.setIsbn(Tisbn);
				try {
					librosc.liburuakEzabatu(onlineLiburua);
					Emaitza.setText("Buruketa ongi egin da.");
					System.out.println("Buruketa ongi egin da.");
				} catch (SQLException e2) {
					Emaitza.setText("Arazo bat dago zure ezabaketarekin.");
					System.err.println("Arazo bat dago zure ezabaketarekin.");
				}
			}
		});
		Bilatu.setBounds(116, 9, 85, 21);
		frame.getContentPane().add(Bilatu);
		
		JButton Itzuli = new JButton("Itzuli.");
		Itzuli.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				Nagusia mainMenua = new Nagusia();
				mainMenua.frame.setVisible(true);
				frame.setVisible(false);
			}
		});
		Itzuli.setBounds(341, 232, 85, 21);
		frame.getContentPane().add(Itzuli);
	}
}
