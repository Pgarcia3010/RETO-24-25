package azterketa2ebaluazioalehioak;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

import conecxioa.librosc;

public class Liburudatuakaldatzekolehioa {
	
	JFrame frame;
	private JTextField bilatzeko;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Liburudatuakaldatzekolehioa window = new Liburudatuakaldatzekolehioa();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Liburudatuakaldatzekolehioa() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel Isbn = new JLabel("Bilatu Isbna.");
		Isbn.setHorizontalAlignment(SwingConstants.CENTER);
		Isbn.setBounds(10, 10, 85, 13);
		frame.getContentPane().add(Isbn);
		
		bilatzeko = new JTextField();
		bilatzeko.setBounds(105, 7, 96, 19);
		frame.getContentPane().add(bilatzeko);
		bilatzeko.setColumns(10);
		
		JButton Itzuli = new JButton("Itzuli.");
		Itzuli.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				Nagusia mainMenua = new Nagusia();
				mainMenua.frame.setVisible(true);
				frame.setVisible(false);
			}
		});
		Itzuli.setBounds(341, 232, 85, 21);
		frame.getContentPane().add(Itzuli);
		
		JButton bilatu = new JButton("Bilatu.");
		bilatu.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent e) {
				librosc libcon = new librosc();
				String bilatzekoT = bilatzeko.getText();
				
				try {
					libcon.getIsbn(bilatzekoT);
					Datuakaldatulehioa list = new Datuakaldatulehioa();
					list.frame.setVisible(true);
					frame.setVisible(false);
				} catch (Exception e2) {
					System.err.println("Arazoa bilaketarekin");
				}
				
			}
		});
		bilatu.setBounds(10, 33, 85, 21);
		frame.getContentPane().add(bilatu);
	}

}
