package azterketa2ebaluazioalehioak;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

import conecxioa.librosc;
import moduloak.OnlineLiburua;


public class Altaegitekolehioa {
	JFrame frame;
	private JTextField id;
	private JTextField tipo;
	private JTextField nombre;
	private JTextField autor;
	private JTextField precio;
	private JTextField pesoGr;
	private JTextField isbn;
	OnlineLiburua lib;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Altaegitekolehioa window = new Altaegitekolehioa();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Altaegitekolehioa() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		JButton Itzuli = new JButton("Itzuli.");
		Itzuli.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				Nagusia mainMenua = new Nagusia();
				mainMenua.frame.setVisible(true);
				frame.setVisible(false);
			}
		});
		Itzuli.setBounds(341, 232, 85, 21);
		frame.getContentPane().add(Itzuli);
		
		JLabel Id = new JLabel("id");
		Id.setHorizontalAlignment(SwingConstants.CENTER);
		Id.setBounds(10, 10, 45, 13);
		frame.getContentPane().add(Id);
		
		id = new JTextField();
		id.setBounds(65, 7, 96, 19);
		frame.getContentPane().add(id);
		id.setColumns(10);
		
		JLabel Tipo = new JLabel("tipo");
		Tipo.setHorizontalAlignment(SwingConstants.CENTER);
		Tipo.setBounds(10, 33, 45, 13);
		frame.getContentPane().add(Tipo);
		
		JLabel Nombre = new JLabel("nombre");
		Nombre.setHorizontalAlignment(SwingConstants.CENTER);
		Nombre.setBounds(10, 56, 45, 13);
		frame.getContentPane().add(Nombre);
		
		JLabel Autor = new JLabel("autor");
		Autor.setHorizontalAlignment(SwingConstants.CENTER);
		Autor.setBounds(10, 79, 45, 13);
		frame.getContentPane().add(Autor);
		
		JLabel Precio = new JLabel("precio");
		Precio.setHorizontalAlignment(SwingConstants.CENTER);
		Precio.setBounds(10, 102, 45, 13);
		frame.getContentPane().add(Precio);
		
		JLabel Pesogr = new JLabel("pesoGr");
		Pesogr.setHorizontalAlignment(SwingConstants.CENTER);
		Pesogr.setBounds(10, 125, 45, 13);
		frame.getContentPane().add(Pesogr);
		
		tipo = new JTextField();
		tipo.setColumns(10);
		tipo.setBounds(65, 30, 96, 19);
		frame.getContentPane().add(tipo);
		
		nombre = new JTextField();
		nombre.setColumns(10);
		nombre.setBounds(65, 53, 96, 19);
		frame.getContentPane().add(nombre);
		
		autor = new JTextField();
		autor.setColumns(10);
		autor.setBounds(65, 76, 96, 19);
		frame.getContentPane().add(autor);
		
		precio = new JTextField();
		precio.setColumns(10);
		precio.setBounds(65, 99, 96, 19);
		frame.getContentPane().add(precio);
		
		pesoGr = new JTextField();
		pesoGr.setColumns(10);
		pesoGr.setBounds(65, 122, 96, 19);
		frame.getContentPane().add(pesoGr);
		
		JLabel Isbn = new JLabel("isbn");
		Isbn.setHorizontalAlignment(SwingConstants.CENTER);
		Isbn.setBounds(10, 148, 45, 13);
		frame.getContentPane().add(Isbn);
		
		JLabel Altarenemaitza = new JLabel("");
		Altarenemaitza.setBounds(10, 172, 317, 78);
		frame.getContentPane().add(Altarenemaitza);
		
		isbn = new JTextField();
		isbn.setColumns(10);
		isbn.setBounds(65, 145, 96, 19);
		frame.getContentPane().add(isbn);
		
		JButton Gehitu = new JButton("Gehitu.");
		Gehitu.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				librosc libcon = new librosc();
				String identification = id.getText();
				int idint = Integer.parseInt(identification);
				String prize = precio.getText();
				Double prizedouble = Double.parseDouble(prize);
				String weight = pesoGr.getText();
				Double weightdouble = Double.parseDouble(weight);
//				id, mota, izenburua, egilea, isbn, prezioa, pesoGr
				lib = new OnlineLiburua (idint, tipo.getText(), nombre.getText(), autor.getText(), isbn.getText(), prizedouble, weightdouble);
				try {
					libcon.ErregistratuLiburua(lib);
					Altarenemaitza.setText("Liburua erregistratuta.");
				} catch (Exception e2) {
					Altarenemaitza.setText("Liburua ez da erregistratu.");
					System.err.println("Errore bat dago.");
				}
			}
		});
		Gehitu.setBounds(171, 6, 85, 21);
		frame.getContentPane().add(Gehitu);
	}
}
