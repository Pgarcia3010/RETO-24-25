package azterketa2ebaluazioalehioak;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.ScrollPane;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.JFrame;
import javax.print.MultiDocPrintService;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableModel;

import conecxioa.librosc;
import moduloak.Liburua;
import moduloak.OnlineLiburua;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.security.Identity;

public class Nagusia {
	/*
	 * Estos so variables generales.
	 */
	JFrame frame;
	Datuakaldatulehioa datuakaldatulehioa;
	public int v;
	public String a;
	public String l;
	public String o;
	public String r;
	public double e;
	public double s;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Nagusia window = new Nagusia();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	

	/**
	 * Create the application.
	 */
	public Nagusia() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	public void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		/*
		 * Boton para salir de la aplicacion.
		 */
		JButton Irten = new JButton("Irten.");
		Irten.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				frame.setVisible(false);
			}
		});
		Irten.setBounds(341, 232, 85, 21);
		frame.getContentPane().add(Irten);
		
		/*
		 * Boton para registrar libros.
		 */
		JButton Alta = new JButton("Alta eman.");
		Alta.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				Altaegitekolehioa alta = new Altaegitekolehioa();
				alta.frame.setVisible(true);
				frame.setVisible(false);
			}
		});
		Alta.setBounds(10, 10, 102, 21);
		frame.getContentPane().add(Alta);
		
		/*
		 * Boton para cambiar los datos de un libro.
		 */
		JButton Datuak = new JButton("Datuak aldatu");
		Datuak.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				Datuakaldatulehioa list = new Datuakaldatulehioa();
				list.frame.setVisible(true);
				frame.setVisible(false);
			}
		});
		Datuak.setBounds(10, 41, 129, 21);
		frame.getContentPane().add(Datuak);
		
		/*
		 * Boton para borrar libros.
		 * (No funciona)
		 */
		JButton Ezabatu = new JButton("Liburuak ezabatu");
		Ezabatu.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				Liburuakezabatzekolehioa ezabatu = new Liburuakezabatzekolehioa();
				ezabatu.frame.setVisible(true);
				frame.setVisible(false);
				
			}
		});
		Ezabatu.setBounds(10, 72, 150, 21);
		frame.getContentPane().add(Ezabatu);
		
		/*
		 * Boton para mostrar la tabla de los libros.
		 */
		JButton Ikusi = new JButton("Liburuak ikusi");
		Ikusi.addActionListener(new ActionListener() {
			
			/*
			 * Este es el ejecutor del evento.
			 */
			@Override
			public void actionPerformed(ActionEvent u) {
				//Aqui se hace una llamada a la clase que se encarga de conectarse a la base de datos.
				librosc libcon =new librosc();
				//Dentro de este (try) se genera la tabla con todas su funciones.
				try {
					//Aqui se crea la ventana de la tabla.
					JPanel panel = new JPanel(new BorderLayout());
					DefaultTableModel dtm = new DefaultTableModel();
					JTable table = new JTable(dtm);
					String [] colums_data = {"id","tipo","nombre","autor","isbn","precio","pesoGr"};
					JScrollPane scroll = new JScrollPane(table);
					JButton Itzuli = new JButton("Itzuli.");
					JButton erabaki = new JButton("Erabaki liburu ahu.");
					//Aqui se crean las columnas.
					for(String i : colums_data) {
					dtm.addColumn(i);
					}
					//Aqui se añaden las filas con los datos.
					for (OnlineLiburua i :libcon.getliburuak()) {
						dtm.addRow(new Object[] {i.getId(), i.getMota(), i.getIzenburua(), i.getEgilea(), i.getIsbn(), i.getPrezioa(), i.getPesoGr()});
					}
					
					panel.add(scroll, BorderLayout.CENTER);
					panel.add(Itzuli, BorderLayout.SOUTH);
					panel.add(erabaki, BorderLayout.EAST);
					frame.setContentPane(panel);
					frame.setBounds(100, 100, 1000, 300);
					frame.setLocationRelativeTo(null);
					frame.setResizable(false);
					Nagusia mainMenua = new Nagusia();
					mainMenua.frame.setVisible(true);
					frame.setVisible(true);
					//Este es el boton que selecciona los datos de una fila.
					erabaki.addMouseListener(new MouseListener() {
						
						@Override
						public void mouseReleased(MouseEvent e) {
							// TODO Auto-generated method stub
							
						}
						
						@Override
						public void mousePressed(MouseEvent e) {
							// TODO Auto-generated method stub
							
						}
						
						@Override
						public void mouseExited(MouseEvent e) {
							// TODO Auto-generated method stub
							
						}
						
						@Override
						public void mouseEntered(MouseEvent e) {
							// TODO Auto-generated method stub
							
						}
						//Este es el evento para seleccionar el dato.
						@Override
						public void mouseClicked(MouseEvent u) {
							datuakaldatulehioa = new Datuakaldatulehioa();
							datuakaldatulehioa.frame.setVisible(true);
							OnlineLiburua onlineLiburua = new OnlineLiburua();
							int line = table.getSelectedRow();
							if (line != -1) {		
									v = (int) table.getValueAt(line, 0);
									a = (String) table.getValueAt(line, 1);
									l = (String) table.getValueAt(line, 2);
									o = (String) table.getValueAt(line, 3);
									r = (String) table.getValueAt(line, 4);
									e = (double) table.getValueAt(line, 5);
									s = (double) table.getValueAt(line, 6);
									onlineLiburua.setId(v);
									onlineLiburua.setMota(a);
									onlineLiburua.setIzenburua(l);
									onlineLiburua.setEgilea(o);
									onlineLiburua.setIsbn(r);
									onlineLiburua.setPrezioa(e);
									onlineLiburua.setPesoGr(s);
									System.out.println(onlineLiburua);
									BaloreaBidali(onlineLiburua);
							}
						}
					});
					//Este es el boton para salir de la tabla y volver al menu principal.
					Itzuli.addActionListener(new ActionListener() {
						
						@Override
						public void actionPerformed(ActionEvent e) {
							frame.setVisible(false);
						}
					});
				} 
				catch (Exception e2) {
					System.err.println("Fallo.");
				}
				
			}
		});
		Ikusi.setBounds(10, 103, 129, 21);
		frame.getContentPane().add(Ikusi);
	}
	/*
	 * Metodo para enviar datos a otra clase.
	 */
	public void BaloreaBidali(OnlineLiburua onlineLiburua) {
		datuakaldatulehioa.BaloreaJaso(onlineLiburua);
	}
	
}
